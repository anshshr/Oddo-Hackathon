import streamlit as st
import cv2
import numpy as np
import mediapipe as mp
import os
import time
import math

# Set page config
st.set_page_config(
    page_title="Virtual Clothing Try-On",
    page_icon="👕",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize MediaPipe
@st.cache_resource
def init_mediapipe():
    mp_pose = mp.solutions.pose
    pose = mp_pose.Pose(
        static_image_mode=False,
        model_complexity=1,
        enable_segmentation=False,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    )
    mp_drawing = mp.solutions.drawing_utils
    return pose, mp_drawing, mp_pose

# Initialize session state
if 'camera_active' not in st.session_state:
    st.session_state.camera_active = False
if 'pose_detector' not in st.session_state:
    st.session_state.pose_detector, st.session_state.mp_drawing, st.session_state.mp_pose = init_mediapipe()

def load_clothing_image(image_path):
    """Load and preprocess clothing image"""
    try:
        if os.path.exists(image_path):
            img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
            if img is not None:
                # Convert BGR to BGRA if no alpha channel
                if img.shape[2] == 3:
                    img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)
                return img
        return None
    except Exception as e:
        st.error(f"Error loading image {image_path}: {str(e)}")
        return None

def analyze_body_measurements(keypoints):
    """Analyze key body points and calculate measurements"""
    if not keypoints or not keypoints.pose_landmarks:
        return None
    
    landmarks = keypoints.pose_landmarks.landmark
    mp_pose = st.session_state.mp_pose
    
    # Get key body landmarks
    left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER]
    right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER]
    left_hip = landmarks[mp_pose.PoseLandmark.LEFT_HIP]
    right_hip = landmarks[mp_pose.PoseLandmark.RIGHT_HIP]
    nose = landmarks[mp_pose.PoseLandmark.NOSE]
    left_elbow = landmarks[mp_pose.PoseLandmark.LEFT_ELBOW]
    right_elbow = landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW]
    left_wrist = landmarks[mp_pose.PoseLandmark.LEFT_WRIST]
    right_wrist = landmarks[mp_pose.PoseLandmark.RIGHT_WRIST]
    
    # Calculate measurements
    measurements = {
        'shoulder_width': math.sqrt((right_shoulder.x - left_shoulder.x)**2 + 
                                   (right_shoulder.y - left_shoulder.y)**2),
        'torso_height': math.sqrt((left_hip.y - left_shoulder.y)**2 + 
                                 (left_hip.x - left_shoulder.x)**2),
        'neck_to_shoulder_left': math.sqrt((left_shoulder.x - nose.x)**2 + 
                                          (left_shoulder.y - nose.y)**2),
        'neck_to_shoulder_right': math.sqrt((right_shoulder.x - nose.x)**2 + 
                                           (right_shoulder.y - nose.y)**2),
        'arm_length_left': math.sqrt((left_wrist.x - left_shoulder.x)**2 + 
                                    (left_wrist.y - left_shoulder.y)**2),
        'arm_length_right': math.sqrt((right_wrist.x - right_shoulder.x)**2 + 
                                     (right_wrist.y - right_shoulder.y)**2),
        'shoulder_center_x': (left_shoulder.x + right_shoulder.x) / 2,
        'shoulder_center_y': (left_shoulder.y + right_shoulder.y) / 2,
        'hip_center_x': (left_hip.x + right_hip.x) / 2,
        'hip_center_y': (left_hip.y + right_hip.y) / 2,
        'torso_center_x': ((left_shoulder.x + right_shoulder.x) / 2 + 
                          (left_hip.x + right_hip.x) / 2) / 2,
        'torso_center_y': ((left_shoulder.y + right_shoulder.y) / 2 + 
                          (left_hip.y + right_hip.y) / 2) / 2
    }
    
    return measurements

def calculate_shirt_fit_parameters(measurements, frame_shape):
    """Calculate shirt fitting parameters based on body measurements"""
    if not measurements:
        return None
    
    h, w = frame_shape[:2]
    
    # Convert normalized coordinates to pixel coordinates
    shoulder_width_px = measurements['shoulder_width'] * w
    torso_height_px = measurements['torso_height'] * h
    
    # Calculate shirt dimensions based on body proportions
    shirt_width = int(shoulder_width_px * 1.8)  # 80% wider than shoulders
    shirt_height = int(torso_height_px * 1.4)   # 40% longer than torso
    
    # Ensure minimum and maximum sizes
    shirt_width = max(min(shirt_width, int(w * 0.6)), 120)  # Min 120px, max 60% of frame
    shirt_height = max(min(shirt_height, int(h * 0.7)), 150)  # Min 150px, max 70% of frame
    
    # Calculate position based on torso center
    center_x = int(measurements['torso_center_x'] * w)
    center_y = int(measurements['torso_center_y'] * h)
    
    # Adjust vertical position to align with shoulders
    shoulder_center_y = int(measurements['shoulder_center_y'] * h)
    shirt_top = shoulder_center_y - int(shirt_height * 0.1)  # Start slightly above shoulders
    
    # Calculate shirt boundaries
    shirt_left = center_x - shirt_width // 2
    shirt_right = center_x + shirt_width // 2
    shirt_bottom = shirt_top + shirt_height
    
    # Ensure shirt stays within frame bounds
    shirt_left = max(0, shirt_left)
    shirt_right = min(w, shirt_right)
    shirt_top = max(0, shirt_top)
    shirt_bottom = min(h, shirt_bottom)
    
    # Recalculate actual dimensions
    actual_width = shirt_right - shirt_left
    actual_height = shirt_bottom - shirt_top
    
    fit_params = {
        'width': actual_width,
        'height': actual_height,
        'left': shirt_left,
        'top': shirt_top,
        'right': shirt_right,
        'bottom': shirt_bottom,
        'center_x': center_x,
        'center_y': center_y,
        'shoulder_alignment': shoulder_center_y
    }
    
    return fit_params

def apply_intelligent_clothing_overlay(frame, clothing_image, keypoints):
    """Apply clothing overlay with intelligent body analysis and fitting"""
    if not keypoints or not keypoints.pose_landmarks or clothing_image is None:
        return frame
    
    # Analyze body measurements
    measurements = analyze_body_measurements(keypoints)
    if not measurements:
        return frame
    
    # Calculate shirt fit parameters
    fit_params = calculate_shirt_fit_parameters(measurements, frame.shape)
    if not fit_params:
        return frame
    
    try:
        # Resize clothing image to fit calculated dimensions
        clothing_resized = cv2.resize(clothing_image, (fit_params['width'], fit_params['height']))
        
        # Create overlay
        overlay = frame.copy()
        
        # Apply clothing with alpha blending if available
        if clothing_resized.shape[2] == 4:
            # Extract alpha channel
            alpha = clothing_resized[:, :, 3] / 255.0
            alpha = np.stack([alpha, alpha, alpha], axis=2)
            
            # Extract RGB channels
            clothing_rgb = clothing_resized[:, :, :3]
            
            # Get region of interest
            roi = frame[fit_params['top']:fit_params['bottom'], 
                       fit_params['left']:fit_params['right']]
            
            # Blend with background
            blended = alpha * clothing_rgb + (1 - alpha) * roi
            overlay[fit_params['top']:fit_params['bottom'], 
                   fit_params['left']:fit_params['right']] = blended.astype(np.uint8)
        else:
            # Simple overlay without alpha
            overlay[fit_params['top']:fit_params['bottom'], 
                   fit_params['left']:fit_params['right']] = clothing_resized[:, :, :3]
        
        # Apply transparency
        alpha = 0.8
        frame = cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0)
        
        # Add fitting guide lines (optional debug)
        if st.session_state.get('show_fitting_guides', False):
            # Draw shoulder line
            landmarks = keypoints.pose_landmarks.landmark
            h, w = frame.shape[:2]
            left_shoulder = landmarks[st.session_state.mp_pose.PoseLandmark.LEFT_SHOULDER]
            right_shoulder = landmarks[st.session_state.mp_pose.PoseLandmark.RIGHT_SHOULDER]
            
            cv2.line(frame, 
                    (int(left_shoulder.x * w), int(left_shoulder.y * h)),
                    (int(right_shoulder.x * w), int(right_shoulder.y * h)),
                    (0, 255, 0), 2)
            
            # Draw torso center
            cv2.circle(frame, (fit_params['center_x'], fit_params['center_y']), 5, (255, 0, 0), -1)
            
            # Draw shirt boundaries
            cv2.rectangle(frame, 
                         (fit_params['left'], fit_params['top']), 
                         (fit_params['right'], fit_params['bottom']), 
                         (0, 255, 255), 2)
        
    except Exception as e:
        st.error(f"Error applying intelligent clothing overlay: {str(e)}")
        # Fall back to simple rectangle
        cv2.rectangle(frame, 
                     (fit_params['left'], fit_params['top']), 
                     (fit_params['right'], fit_params['bottom']), 
                     (0, 255, 0), 2)
        cv2.putText(frame, "SHIRT FIT ERROR", 
                   (fit_params['left'] + 10, fit_params['top'] + 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    
    return frame

def display_body_analysis(measurements, fit_params):
    """Display body analysis information in sidebar"""
    if not measurements or not fit_params:
        return
    
    st.subheader("📏 Body Analysis")
    
    # Display measurements
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Measurements:**")
        st.write(f"Shoulder Width: {measurements['shoulder_width']:.3f}")
        st.write(f"Torso Height: {measurements['torso_height']:.3f}")
        st.write(f"Left Arm: {measurements['arm_length_left']:.3f}")
        st.write(f"Right Arm: {measurements['arm_length_right']:.3f}")
    
    with col2:
        st.write("**Shirt Fit:**")
        st.write(f"Width: {fit_params['width']}px")
        st.write(f"Height: {fit_params['height']}px")
        st.write(f"Position: ({fit_params['center_x']}, {fit_params['center_y']})")
    
    # Fit quality assessment
    shoulder_ratio = measurements['shoulder_width'] * 1.8
    if 0.7 <= shoulder_ratio <= 1.3:
        st.success("✅ Excellent fit!")
    elif 0.5 <= shoulder_ratio <= 1.5:
        st.warning("⚠️ Good fit")
    else:
        st.error("❌ Poor fit - adjust position")

def test_camera_connection():
    """Test if camera is working"""
    cap = cv2.VideoCapture(0)
    if cap.isOpened():
        ret, frame = cap.read()
        cap.release()
        return ret and frame is not None
    return False

def main():
    st.title("👕 Intelligent Virtual Clothing Try-On")
    st.markdown("---")
    
    # Test camera connection
    if st.button("🔧 Test Camera Connection"):
        if test_camera_connection():
            st.success("✅ Camera is working properly!")
        else:
            st.error("❌ Camera connection failed!")
    
    # Create columns for layout
    col1, col2 = st.columns([2, 1])
    
    with col2:
        st.header("🎛️ Controls")
        
        # Clothing selection
        st.subheader("Select Clothing")
        clothing_options = {
            "Shirt 1": "assets/image.png",
            "Shirt 2": "assets/image1.png",
            "Shirt 3": "assets/image2.png",
            "Shirt 4": "assets/image3.png"
        }
        
        selected_clothing = st.selectbox(
            "Choose a clothing item:",
            list(clothing_options.keys()),
            key="clothing_select"
        )
        
        # Load and display selected clothing image
        clothing_path = clothing_options[selected_clothing]
        clothing_image = load_clothing_image(clothing_path)
        
        if clothing_image is not None:
            # Display preview of clothing item
            display_img = clothing_image.copy()
            if display_img.shape[2] == 4:
                display_img = cv2.cvtColor(display_img, cv2.COLOR_BGRA2RGB)
            else:
                display_img = cv2.cvtColor(display_img, cv2.COLOR_BGR2RGB)
            
            st.image(display_img, caption=f"Selected: {selected_clothing}", width=200)
            st.success(f"✅ {selected_clothing} loaded successfully")
        else:
            st.error(f"❌ Could not load {selected_clothing} from {clothing_path}")
            st.info("Please ensure the image file exists in the assets folder")
        
        # Camera controls
        st.subheader("📷 Camera")
        camera_button = st.button("Start/Stop Camera", key="camera_toggle")
        
        if camera_button:
            st.session_state.camera_active = not st.session_state.camera_active
        
        # Settings
        st.subheader("⚙️ Settings")
        show_landmarks = st.checkbox("Show Pose Landmarks", value=False)
        show_fitting_guides = st.checkbox("Show Fitting Guides", value=False)
        st.session_state.show_fitting_guides = show_fitting_guides
        
        pose_confidence = st.slider("Pose Detection Confidence", 0.1, 1.0, 0.5, 0.1)
        overlay_opacity = st.slider("Clothing Opacity", 0.1, 1.0, 0.8, 0.1)
        
        # Update pose detector confidence
        st.session_state.pose_detector.min_detection_confidence = pose_confidence
        
        # Body analysis display placeholder
        analysis_placeholder = st.empty()
        
        # Debug info
        st.subheader("🔍 Debug Info")
        st.write(f"Camera Status: {'🟢 Active' if st.session_state.camera_active else '🔴 Inactive'}")
        st.write(f"Selected Item: {selected_clothing}")
        st.write(f"Image Path: {clothing_path}")
        st.write(f"Image Loaded: {'✅' if clothing_image is not None else '❌'}")
        st.write(f"Show Landmarks: {'✅' if show_landmarks else '❌'}")
        st.write(f"Show Fitting Guides: {'✅' if show_fitting_guides else '❌'}")
        
    with col1:
        st.header("📹 Live Preview")
        
        # Video frame placeholder
        frame_placeholder = st.empty()
        
        if st.session_state.camera_active:
            # Initialize camera
            cap = cv2.VideoCapture(0)
            
            if not cap.isOpened():
                st.error("❌ Could not open camera. Please check your camera connection.")
                st.session_state.camera_active = False
            else:
                st.success("✅ Camera is active")
                
                # Load current clothing image
                current_clothing_path = clothing_options[selected_clothing]
                current_clothing_image = load_clothing_image(current_clothing_path)
                
                # Create a container for the video stream
                with st.container():
                    # Stop button
                    stop_col1, stop_col2, stop_col3 = st.columns([1, 1, 1])
                    with stop_col2:
                        if st.button("🛑 Stop Camera", key="stop_camera"):
                            st.session_state.camera_active = False
                            cap.release()
                            st.rerun()
                    
                    # Process video frames
                    frame_count = 0
                    while st.session_state.camera_active:
                        ret, frame = cap.read()
                        
                        if not ret:
                            st.error("❌ Failed to capture frame")
                            break
                        
                        # Flip frame horizontally for mirror effect
                        frame = cv2.flip(frame, 1)
                        
                        # Detect pose
                        try:
                            results = st.session_state.pose_detector.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                            
                            # Apply intelligent clothing overlay
                            if results.pose_landmarks and current_clothing_image is not None:
                                frame = apply_intelligent_clothing_overlay(frame, current_clothing_image, results)
                                
                                # Update body analysis display
                                measurements = analyze_body_measurements(results)
                                fit_params = calculate_shirt_fit_parameters(measurements, frame.shape)
                                
                                with analysis_placeholder.container():
                                    display_body_analysis(measurements, fit_params)
                            
                            # Draw landmarks if enabled
                            if show_landmarks and results.pose_landmarks:
                                st.session_state.mp_drawing.draw_landmarks(
                                    frame, results.pose_landmarks, 
                                    st.session_state.mp_pose.POSE_CONNECTIONS
                                )
                            
                            # Add frame counter for debugging
                            frame_count += 1
                            cv2.putText(frame, f"Frame: {frame_count}", (10, 30), 
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                            
                            # Add pose detection status
                            status = "Pose Detected" if results.pose_landmarks else "No Pose"
                            cv2.putText(frame, status, (10, 60), 
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0) if results.pose_landmarks else (0, 0, 255), 2)
                            
                            # Add clothing status
                            clothing_status = "Clothing Loaded" if current_clothing_image is not None else "No Clothing"
                            cv2.putText(frame, clothing_status, (10, 90), 
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0) if current_clothing_image is not None else (0, 0, 255), 2)
                            
                        except Exception as e:
                            st.error(f"Error in pose detection: {str(e)}")
                            # Continue with original frame
                        
                        # Convert BGR to RGB for Streamlit
                        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                        
                        # Display frame
                        frame_placeholder.image(frame_rgb, channels="RGB", use_container_width=True)
                        
                        # Small delay to prevent overwhelming the display
                        time.sleep(0.03)
                        
                        # Check if we should stop
                        if not st.session_state.camera_active:
                            break
                
                cap.release()
        else:
            # Show placeholder when camera is not active
            placeholder_text = """
            ### 📷 Camera Not Active
            
            Click **"Start/Stop Camera"** to begin the intelligent virtual try-on experience.
            
            **Enhanced Features:**
            - 🧠 **Intelligent Body Analysis**: Analyzes neck, shoulders, and torso proportions
            - 📏 **Precise Measurements**: Calculates shoulder width, torso height, and arm length
            - 👕 **Smart Shirt Fitting**: Automatically adjusts shirt size and position
            - 🎯 **Alignment System**: Ensures perfect shirt alignment with body
            - 📊 **Fit Quality Assessment**: Real-time feedback on shirt fit
            - 🔍 **Fitting Guides**: Visual guides for debugging fit accuracy
            
            **Required Assets:**
            - `assets/image.png` - Shirt 1
            - `assets/image1.png` - Shirt 2
            - `assets/image2.png` - Shirt 3
            - `assets/image3.png` - Shirt 4
            
            **Instructions:**
            1. Place clothing images in the `assets/` folder
            2. Click "Test Camera Connection" first
            3. Select a clothing item
            4. Enable "Show Fitting Guides" for debugging
            5. Click "Start/Stop Camera"
            6. Stand straight facing the camera
            7. Watch the shirt automatically fit your body proportions
            """
            frame_placeholder.markdown(placeholder_text)
    
    # Footer
    st.markdown("---")
    st.markdown(
        """
        <div style='text-align: center; color: #666;'>
            <p>🤖 Powered by MediaPipe & OpenCV | Built with Streamlit</p>
            <p>🧠 Intelligent Body Analysis & Smart Shirt Fitting</p>
        </div>
        """, 
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()