import cv2
import numpy as np
from PIL import Image
import os

class ClothingOverlay:
    def __init__(self):
        pass

    def apply_clothing(self, frame, clothing_image_path, keypoints):
        """
        Apply clothing overlay to the frame based on MediaPipe pose keypoints
        """
        if keypoints is None or len(keypoints) == 0:
            return frame

        # Load clothing image
        if not os.path.exists(clothing_image_path):
            return frame

        # Load clothing image with alpha channel support
        clothing_image = cv2.imread(clothing_image_path, cv2.IMREAD_UNCHANGED)
        if clothing_image is None:
            return frame

        # Convert to RGBA if needed
        if clothing_image.shape[2] == 3:
            clothing_image = cv2.cvtColor(clothing_image, cv2.COLOR_BGR2BGRA)

        # MediaPipe pose landmark indices
        # 11: Left shoulder, 12: Right shoulder, 23: Left hip, 24: Right hip
        if len(keypoints) >= 25:
            left_shoulder = keypoints[11]   # (x, y, z)
            right_shoulder = keypoints[12]  # (x, y, z)
            left_hip = keypoints[23]        # (x, y, z)
            right_hip = keypoints[24]       # (x, y, z)
            
            # Convert normalized coordinates to pixel coordinates
            h, w = frame.shape[:2]
            left_shoulder_px = (int(left_shoulder[0] * w), int(left_shoulder[1] * h))
            right_shoulder_px = (int(right_shoulder[0] * w), int(right_shoulder[1] * h))
            left_hip_px = (int(left_hip[0] * w), int(left_hip[1] * h))
            right_hip_px = (int(right_hip[0] * w), int(right_hip[1] * h))
            
            # Calculate clothing dimensions
            shoulder_width = abs(left_shoulder_px[0] - right_shoulder_px[0])
            torso_height = abs(left_shoulder_px[1] - left_hip_px[1])
            
            # Set clothing size based on body proportions
            clothing_width = max(int(shoulder_width * 1.8), 100)
            clothing_height = max(int(torso_height * 1.5), 120)
            
            # Calculate center position
            center_x = (left_shoulder_px[0] + right_shoulder_px[0]) // 2
            center_y = (left_shoulder_px[1] + right_shoulder_px[1]) // 2
            
            # Resize clothing image
            clothing_resized = cv2.resize(clothing_image, (clothing_width, clothing_height))
            
            # Calculate overlay position
            x_offset = center_x - clothing_width // 2
            y_offset = center_y - clothing_height // 8  # Adjust vertical position
            
            # Overlay the clothing on the frame
            frame = self.overlay_image(frame, clothing_resized, x_offset, y_offset)

        return frame

    def overlay_image(self, background, overlay, x_offset, y_offset):
        """
        Overlay an image with alpha channel on background
        """
        background_height, background_width = background.shape[:2]
        overlay_height, overlay_width = overlay.shape[:2]
        
        # Calculate the region of interest
        x1 = max(0, x_offset)
        y1 = max(0, y_offset)
        x2 = min(background_width, x_offset + overlay_width)
        y2 = min(background_height, y_offset + overlay_height)
        
        # Calculate overlay region
        overlay_x1 = max(0, -x_offset)
        overlay_y1 = max(0, -y_offset)
        overlay_x2 = overlay_x1 + (x2 - x1)
        overlay_y2 = overlay_y1 + (y2 - y1)
        
        if x1 >= x2 or y1 >= y2:
            return background
        
        # Get the overlay region
        overlay_region = overlay[overlay_y1:overlay_y2, overlay_x1:overlay_x2]
        
        if overlay_region.shape[2] == 4:  # Has alpha channel
            # Split channels
            overlay_bgr = overlay_region[:, :, :3]
            overlay_alpha = overlay_region[:, :, 3:4] / 255.0
            
            # Get background region
            background_region = background[y1:y2, x1:x2]
            
            # Blend images
            blended = overlay_bgr * overlay_alpha + background_region * (1 - overlay_alpha)
            background[y1:y2, x1:x2] = blended.astype(np.uint8)
        else:
            # No alpha channel, direct copy
            background[y1:y2, x1:x2] = overlay_region
        
        return background