import cv2
import numpy as np
import os

def create_placeholder_clothing():
    """Create placeholder clothing images for testing"""
    
    # Create directory if it doesn't exist
    clothing_dir = "src/assets/clothing"
    os.makedirs(clothing_dir, exist_ok=True)
    
    # Define clothing colors and names
    clothes = [
        ("shirt1.png", (0, 0, 255)),      # Red shirt
        ("shirt2.png", (255, 0, 0)),      # Blue shirt
        ("shirt3.png", (0, 255, 0)),      # Green shirt
        ("shirt4.png", (255, 255, 0))     # Yellow shirt
    ]
    
    # Create each clothing image
    for filename, color in clothes:
        # Create a simple shirt shape
        img = np.zeros((300, 250, 4), dtype=np.uint8)  # RGBA image
        
        # Main body of shirt
        cv2.rectangle(img, (50, 100), (200, 280), (*color, 255), -1)
        
        # Sleeves
        cv2.rectangle(img, (10, 100), (60, 180), (*color, 255), -1)
        cv2.rectangle(img, (190, 100), (240, 180), (*color, 255), -1)
        
        # Collar
        cv2.rectangle(img, (90, 80), (160, 120), (*color, 255), -1)
        
        # Add some simple details
        cv2.rectangle(img, (70, 120), (180, 130), (255, 255, 255, 255), -1)  # White stripe
        
        # Save the image
        filepath = os.path.join(clothing_dir, filename)
        cv2.imwrite(filepath, img)
        print(f"Created {filepath}")

if __name__ == "__main__":
    create_placeholder_clothing()
    print("Placeholder clothing images created successfully!")
